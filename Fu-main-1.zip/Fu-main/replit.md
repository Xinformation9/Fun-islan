# Fun Island - جزيرة المرح

A full children's educational mobile app for ages 3–10 built with Expo/React Native.

## Architecture

- **Framework**: Expo ~54 with expo-router ~6.0.17
- **Stack**: React Native 0.81.5, TypeScript, AsyncStorage (no backend)
- **State**: Two React context providers — `AppContext` (stars/coins/XP/missions/achievements) + `ParentContext` (PIN/settings)
- **Navigation**: Stack-based via expo-router, no tab bar

## App Structure

```
artifacts/fun-island/
├── app/
│   ├── _layout.tsx          # Root layout with all providers
│   ├── (tabs)/
│   │   ├── _layout.tsx      # Stack layout wrapper
│   │   └── index.tsx        # Island home map (main screen)
│   ├── video/index.tsx      # Video island (YouTube via WebView on native)
│   ├── games/
│   │   ├── index.tsx        # Games lobby
│   │   ├── memory-match.tsx
│   │   ├── alphabet-adventure.tsx
│   │   ├── number-quest.tsx
│   │   ├── word-connect.tsx
│   │   ├── rabbit-runner.tsx
│   │   ├── coloring-studio.tsx
│   │   └── puzzle-master.tsx
│   ├── music/index.tsx      # Music player
│   ├── stories/
│   │   ├── index.tsx        # Stories library
│   │   └── [id].tsx         # Story reader
│   ├── rewards/index.tsx    # Gamification dashboard
│   └── parent/index.tsx     # Parent dashboard (PIN protected)
├── components/
│   ├── IslandZone.tsx       # Animated zone card
│   ├── StarsCoinsBar.tsx    # Top stats bar
│   ├── MascotGuide.tsx      # Animated mascot helper
│   ├── RewardModal.tsx      # Celebration popup
│   ├── ErrorBoundary.tsx
│   └── ErrorFallback.tsx
├── context/
│   ├── AppContext.tsx        # Stars/coins/XP/missions state + AsyncStorage
│   └── ParentContext.tsx     # PIN/settings state
├── hooks/
│   └── useColors.ts         # Light/dark color scheme hook
├── constants/
│   └── colors.ts            # Color palette (light + dark, tropical theme)
└── data/
    ├── videos.ts            # Video catalog
    ├── songs.ts             # Music catalog
    ├── stories.ts           # Stories content
    ├── games.ts             # Game definitions
    └── achievements.ts      # Achievement definitions
```

## Features

- **6 Island Zones**: Videos, Games, Music, Stories, Rewards, Parents
- **7 Mini-Games**: Memory Match, Alphabet Adventure, Number Quest, Word Connect, Rabbit Runner, Coloring Studio, Puzzle Master
- **Music Player**: Full-screen player with categories and a song list
- **Stories Library**: Illustrated stories with page-by-page reader
- **Gamification**: Stars ⭐, Coins 🪙, XP, Levels, Daily Missions, Achievements, Character collection
- **Parent Dashboard**: PIN-protected settings with usage reports
- **Multilingual**: English, Arabic (RTL), French
- **Theme**: Tropical island — ocean blue (#0096C7), orange accent (#FF9F1C), sky gradient background

## Color Theme

- Primary: `#0096C7` (ocean blue)
- Accent: `#FF9F1C` (orange)
- Background: `#E0F7FF` (light sky)
- Island gradient: `#87CEEB → #48A9D8 → #0077B6`

## Key Technical Notes

- `react-native-webview` is used for YouTube videos on native only (conditional require)
- `KeyboardProvider` from `react-native-keyboard-controller` is native-only (skipped on web)
- Vector icon fonts load asynchronously via `Font.loadAsync(Feather.font)` in the background
- `SplashScreen.hideAsync()` fires immediately on mount (no font blocking)
- `useNativeDriver: true` falls back to JS on web — this is expected behavior

## Workflow

- **Dev**: `pnpm --filter @workspace/fun-island run dev`
- **Port**: 20664
- **Preview**: Via REPLIT_EXPO_DEV_DOMAIN (Expo mobile domain, not shared proxy)
- **Mobile**: Scan QR code in workflow logs with Expo Go app

## Dependencies

Key packages:
- `expo-linear-gradient`, `expo-haptics`, `expo-blur`, `expo-splash-screen`
- `react-native-svg` (Coloring Studio game)
- `react-native-reanimated`, `react-native-gesture-handler`
- `react-native-safe-area-context`, `react-native-screens`
- `@react-native-async-storage/async-storage`
- `@expo/vector-icons`
- `react-native-webview` (native video playback)
- `react-native-keyboard-controller` (native only)
