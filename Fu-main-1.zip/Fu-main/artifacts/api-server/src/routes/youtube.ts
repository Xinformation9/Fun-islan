import { ListChannelVideosQueryParams, ListChannelVideosResponse } from "@workspace/api-zod";
import { Router, type IRouter } from "express";

const router: IRouter = Router();
const YOUTUBE_API_BASE = "https://www.googleapis.com/youtube/v3";
const CHANNEL_ID =
  process.env.YOUTUBE_CHANNEL_ID ??
  process.env.EXPO_PUBLIC_YOUTUBE_CHANNEL_ID ??
  "UCUUhJYRe-0NF9A_tKIAmY8g";
const CACHE_TTL_MS = 5 * 60 * 1000;
const MAX_CACHE_ENTRIES = 100;
const responseCache = new Map<string, { expiresAt: number; body: unknown }>();

type YouTubeSearchResponse = {
  items?: Array<{
    id?: { videoId?: string };
    snippet?: {
      title?: string;
      description?: string;
      publishedAt?: string;
      channelTitle?: string;
      thumbnails?: {
        high?: { url?: string };
        medium?: { url?: string };
        default?: { url?: string };
      };
    };
  }>;
  nextPageToken?: string;
};

router.get("/youtube/videos", async (req, res): Promise<void> => {
  const query = ListChannelVideosQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: "معايير البحث غير صالحة." });
    return;
  }

  const apiKey = process.env.GOOGLE_API_KEY;
  if (!apiKey) {
    req.log.error("YouTube API key is not configured");
    res.status(503).json({ error: "خدمة الفيديوهات غير مهيأة حالياً." });
    return;
  }

  const params = new URLSearchParams({
    part: "snippet",
    channelId: CHANNEL_ID,
    maxResults: String(query.data.maxResults),
    order: "date",
    type: "video",
    safeSearch: "strict",
    videoEmbeddable: "true",
  });
  const searchTerm = query.data.query?.trim();
  if (searchTerm) params.set("q", searchTerm);
  if (query.data.pageToken) params.set("pageToken", query.data.pageToken);

  const cacheKey = JSON.stringify([
    CHANNEL_ID,
    query.data.maxResults,
    searchTerm ?? "",
    query.data.pageToken ?? "",
  ]);
  const cached = responseCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    res.json(cached.body);
    return;
  }
  if (cached) responseCache.delete(cacheKey);

  const url = new URL(`${YOUTUBE_API_BASE}/search`);
  url.search = params.toString();
  url.searchParams.set("key", apiKey);

  let response: Response;
  try {
    response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
  } catch {
    req.log.warn("YouTube API request timed out or could not connect");
    res.status(502).json({ error: "تعذر الاتصال بخدمة الفيديوهات. حاول مرة أخرى." });
    return;
  }

  if (!response.ok) {
    req.log.warn({ status: response.status }, "YouTube API returned an error");
    res.status(502).json({ error: "تعذر جلب فيديوهات القناة الآن. حاول مرة أخرى." });
    return;
  }

  let data: YouTubeSearchResponse;
  try {
    data = (await response.json()) as YouTubeSearchResponse;
  } catch {
    req.log.warn("YouTube API returned invalid JSON");
    res.status(502).json({ error: "وصلت بيانات غير صالحة من خدمة الفيديوهات." });
    return;
  }

  const videos = (data.items ?? [])
    .map((item) => {
      const videoId = item.id?.videoId;
      const snippet = item.snippet;
      if (!videoId || !snippet?.publishedAt) return null;

      return {
        id: videoId,
        title: snippet.title ?? "فيديو جديد",
        description: snippet.description ?? "",
        thumbnail:
          snippet.thumbnails?.high?.url ??
          snippet.thumbnails?.medium?.url ??
          snippet.thumbnails?.default?.url ??
          `https://i.ytimg.com/vi/${encodeURIComponent(videoId)}/hqdefault.jpg`,
        publishedAt: snippet.publishedAt,
        channelTitle: snippet.channelTitle ?? "جزيرة المرح",
      };
    })
    .filter((video): video is NonNullable<typeof video> => video !== null)
    .sort(
      (left, right) =>
        new Date(right.publishedAt).getTime() - new Date(left.publishedAt).getTime(),
    );

  const result = ListChannelVideosResponse.safeParse({
    videos,
    nextPageToken: data.nextPageToken ?? null,
  });
  if (!result.success) {
    req.log.warn("YouTube API response did not match the video contract");
    res.status(502).json({ error: "تعذر قراءة بيانات فيديوهات القناة." });
    return;
  }

  const now = Date.now();
  for (const [key, entry] of responseCache) {
    if (entry.expiresAt <= now) responseCache.delete(key);
  }
  if (responseCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = responseCache.keys().next().value;
    if (oldestKey) responseCache.delete(oldestKey);
  }
  responseCache.set(cacheKey, {
    expiresAt: now + CACHE_TTL_MS,
    body: result.data,
  });

  res.json(result.data);
});

export default router;
