import Seo from '@/components/Seo';
import AdSlot from '@/components/AdSlot';
import { useMemo, useState } from 'react';
import { ArrowLeft, BookOpen, CheckCircle2, Headphones, Languages, RefreshCw, Star, Volume2 } from 'lucide-react';

type Lang = 'ar' | 'en' | 'fr';
type LetterItem = { letter: string; word: string; meaning: string };
const alphabet: Record<Lang, LetterItem[]> = {
  ar: [
    { letter: 'ا', word: 'أسد', meaning: 'lion' }, { letter: 'ب', word: 'بطة', meaning: 'duck' }, { letter: 'ت', word: 'تفاح', meaning: 'apple' }, { letter: 'ث', word: 'ثعلب', meaning: 'fox' },
    { letter: 'ج', word: 'جمل', meaning: 'camel' }, { letter: 'ح', word: 'حصان', meaning: 'horse' }, { letter: 'خ', word: 'خروف', meaning: 'sheep' }, { letter: 'د', word: 'دب', meaning: 'bear' },
    { letter: 'ذ', word: 'ذرة', meaning: 'corn' }, { letter: 'ر', word: 'ريشة', meaning: 'feather' }, { letter: 'ز', word: 'زهرة', meaning: 'flower' }, { letter: 'س', word: 'سمكة', meaning: 'fish' },
    { letter: 'ش', word: 'شمس', meaning: 'sun' }, { letter: 'ص', word: 'صقر', meaning: 'falcon' }, { letter: 'ض', word: 'ضفدع', meaning: 'frog' }, { letter: 'ط', word: 'طائرة', meaning: 'plane' },
    { letter: 'ظ', word: 'ظرف', meaning: 'envelope' }, { letter: 'ع', word: 'عنب', meaning: 'grapes' }, { letter: 'غ', word: 'غيمة', meaning: 'cloud' }, { letter: 'ف', word: 'فراشة', meaning: 'butterfly' },
    { letter: 'ق', word: 'قمر', meaning: 'moon' }, { letter: 'ك', word: 'كتاب', meaning: 'book' }, { letter: 'ل', word: 'ليمون', meaning: 'lemon' }, { letter: 'م', word: 'موز', meaning: 'banana' },
    { letter: 'ن', word: 'نحلة', meaning: 'bee' }, { letter: 'ه', word: 'هدية', meaning: 'gift' }, { letter: 'و', word: 'وردة', meaning: 'rose' }, { letter: 'ي', word: 'يد', meaning: 'hand' },
  ],
  en: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((letter, i) => ({ letter, word: ['Apple', 'Ball', 'Cat', 'Duck', 'Egg', 'Fish', 'Grapes', 'Hat', 'Igloo', 'Jam', 'Kite', 'Lion', 'Moon', 'Nest', 'Orange', 'Penguin', 'Queen', 'Rainbow', 'Sun', 'Tiger', 'Umbrella', 'Violin', 'Whale', 'Xylophone', 'Yo-yo', 'Zebra'][i], meaning: ['تفاحة', 'كرة', 'قطة', 'بطة', 'بيضة', 'سمكة', 'عنب', 'قبعة', 'كوخ جليدي', 'مربى', 'طائرة ورقية', 'أسد', 'قمر', 'عش', 'برتقالة', 'بطريق', 'ملكة', 'قوس قزح', 'شمس', 'نمر', 'مظلة', 'كمان', 'حوت', 'إكسيليفون', 'لعبة يويو', 'حمار وحشي'][i] })),
  fr: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((letter, i) => ({ letter, word: ['Abeille', 'Bateau', 'Chat', 'Dauphin', 'Étoile', 'Fleur', 'Gâteau', 'Hérisson', 'Île', 'Jardin', 'Koala', 'Lune', 'Maison', 'Nuage', 'Orange', 'Papillon', 'Quatre', 'Renard', 'Soleil', 'Tortue', 'Usine', 'Vélo', 'Wagon', 'Xylophone', 'Yaourt', 'Zèbre'][i], meaning: ['نحلة', 'قارب', 'قط', 'دلفين', 'نجمة', 'زهرة', 'كعكة', 'قنفذ', 'جزيرة', 'حديقة', 'كوالا', 'قمر', 'منزل', 'غيمة', 'برتقالة', 'فراشة', 'أربعة', 'ثعلب', 'شمس', 'سلحفاة', 'مصنع', 'دراجة', 'عربة', 'إكسيليفون', 'زبادي', 'حمار وحشي'][i] })),
};
const langs: { id: Lang; label: string; name: string; locale: string; description: string }[] = [
  { id: 'ar', label: 'العربية', name: 'رحلة الحروف العربية', locale: 'ar-SA', description: 'من الألف إلى الياء، خطوة خطوة.' },
  { id: 'en', label: 'English', name: 'English letter trail', locale: 'en-US', description: 'Meet letters, sounds and little words.' },
  { id: 'fr', label: 'Français', name: 'Le sentier des lettres', locale: 'fr-FR', description: 'Découvre les lettres et les mots.' },
];
const levelDetails = [
  { title: 'أول لقاء', titleEn: 'First hello', titleFr: 'Première rencontre', text: 'تعرّف على شكل اللغة وكلماتها الأولى.', activity: 'اختر الحرف الذي تراه.' },
  { title: 'أرى الحرف', titleEn: 'Letter spotting', titleFr: 'Je reconnais la lettre', text: 'تعرّف على ترتيب الحروف وأشكالها.', activity: 'ما الحرف الذي يأتي بعد الحرف المعروض؟' },
  { title: 'أسمع الصوت', titleEn: 'Letter sounds', titleFr: 'J’écoute le son', text: 'استمع للصوت، ثم اختر حرفه.', activity: 'استمع واختر الحرف.' },
  { title: 'كلمات صغيرة', titleEn: 'Little words', titleFr: 'Petits mots', text: 'اربط الحرف بكلمة مألوفة.', activity: 'أي كلمة تبدأ بالحرف المعروض؟' },
  { title: 'جمل بسيطة', titleEn: 'Simple phrases', titleFr: 'Phrases simples', text: 'اقرأ عبارة قصيرة واختر معناها.', activity: 'اقرأ العبارة واختر معناها.' },
  { title: 'قارئ الجزيرة', titleEn: 'Reading mastery', titleFr: 'Lecture maîtrisée', text: 'اقرأ الجمل واستمع إليها وافهم معناها.', activity: 'استمع إلى الجملة واختر معناها.' },
];
type ReadingPrompt = { sentence: string; answer: string; options: string[]; question: string };
const readingPrompts: Record<Lang, ReadingPrompt[]> = {
  ar: [
    { sentence: 'تشرق الشمس صباحاً.', answer: 'تظهر الشمس في الصباح.', options: ['تظهر الشمس في الصباح.', 'ينام القمر صباحاً.', 'يهطل المطر داخل البيت.'], question: 'ماذا تفعل الشمس؟' },
    { sentence: 'تسبح السمكة في الماء.', answer: 'السمكة تتحرك في الماء.', options: ['السمكة تتحرك في الماء.', 'العصفور يطير في السماء.', 'القطة تنام على الكرسي.'], question: 'أين تتحرك السمكة؟' },
    { sentence: 'يقرأ الطفل كتاباً.', answer: 'الطفل يطالع كتاباً.', options: ['الطفل يطالع كتاباً.', 'الطفل يزرع شجرة.', 'الطفل يركب دراجة.'], question: 'ماذا يفعل الطفل؟' },
  ],
  en: [
    { sentence: 'The little bird can fly.', answer: 'العصفور الصغير يستطيع الطيران.', options: ['العصفور الصغير يستطيع الطيران.', 'السمكة الصغيرة تسبح.', 'القطة تنام على السرير.'], question: 'ماذا يستطيع العصفور؟' },
    { sentence: 'The red ball is under the table.', answer: 'الكرة الحمراء تحت الطاولة.', options: ['الكرة الحمراء تحت الطاولة.', 'الكرة الزرقاء فوق الكرسي.', 'الكتاب داخل الحقيبة.'], question: 'أين الكرة الحمراء؟' },
    { sentence: 'Maya reads a funny story.', answer: 'مايا تقرأ قصة مضحكة.', options: ['مايا تقرأ قصة مضحكة.', 'مايا ترسم زهرة.', 'مايا تطعم أرنباً.'], question: 'ماذا تقرأ مايا؟' },
  ],
  fr: [
    { sentence: 'Le petit chat dort.', answer: 'القطة الصغيرة نائمة.', options: ['القطة الصغيرة نائمة.', 'العصفور الصغير يطير.', 'السمكة تسبح بسرعة.'], question: 'ماذا تفعل القطة؟' },
    { sentence: 'Le ballon rouge est sous la table.', answer: 'الكرة الحمراء تحت الطاولة.', options: ['الكرة الحمراء تحت الطاولة.', 'الكرة الزرقاء فوق الكرسي.', 'الكتاب داخل الحقيبة.'], question: 'أين الكرة الحمراء؟' },
    { sentence: 'Lina lit une belle histoire.', answer: 'لينا تقرأ حكاية جميلة.', options: ['لينا تقرأ حكاية جميلة.', 'لينا ترسم قوس قزح.', 'لينا تلعب بالكرة.'], question: 'ماذا تقرأ لينا؟' },
  ],
};
const progressKey = 'fun-island-learning-v1';
function savedProgress(): Record<string, number[]> {
  try { return JSON.parse(localStorage.getItem(progressKey) || '{}') as Record<string, number[]>; } catch { return {}; }
}
function speak(text: string, locale: string) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const voice = new SpeechSynthesisUtterance(text); voice.lang = locale; window.speechSynthesis.speak(voice);
}

export default function LearnPage() {
  const [language, setLanguage] = useState<Lang>('ar'); const [level, setLevel] = useState(0);
  const [challengeOffset, setChallengeOffset] = useState(0);
  const [progress, setProgress] = useState<Record<string, number[]>>(savedProgress);
  const [selected, setSelected] = useState<number | null>(null); const [feedback, setFeedback] = useState('');
  const lang = langs.find((item) => item.id === language)!; const letters = alphabet[language];
  const currentIndex = (level * 3 + challengeOffset) % letters.length;
  const currentLetter = useMemo(() => letters[currentIndex], [letters, currentIndex]);
  const nextLetter = letters[(currentIndex + 1) % letters.length];
  const reading = readingPrompts[language][challengeOffset % readingPrompts[language].length];
  const letterOptions = [currentLetter.letter, letters[(currentIndex + 4) % letters.length].letter, letters[(currentIndex + 7) % letters.length].letter];
  const nextLetterOptions = [nextLetter.letter, letters[(currentIndex + 2) % letters.length].letter, letters[(currentIndex + 3) % letters.length].letter];
  const wordOptions = [currentLetter.word, letters[(currentIndex + 4) % letters.length].word, letters[(currentIndex + 7) % letters.length].word];
  const choices = level === 1 ? nextLetterOptions : level < 3 ? letterOptions : level === 3 ? wordOptions : reading.options;
  const answer = level === 1 ? nextLetter.letter : level < 3 ? currentLetter.letter : level === 3 ? currentLetter.word : reading.answer;
  const completed = progress[language] || [];
  const selectLanguage = (id: Lang) => { setLanguage(id); setLevel(0); setChallengeOffset(0); setSelected(null); setFeedback(''); };
  const finish = () => {
    if (selected === null) return;
    if (choices[selected] === answer) {
      const next = Array.from(new Set([...completed, level])); const all = { ...progress, [language]: next }; setProgress(all);
      try { localStorage.setItem(progressKey, JSON.stringify(all)); } catch { /* Progress remains available for this visit. */ }
      setFeedback('أحسنت! أتممت هذا المستوى. نجمة جديدة في سجلّك.');
    } else setFeedback('محاولة جميلة. استمع أو انظر مرة أخرى ثم جرّب.');
  };
  const pick = (index: number) => { setSelected(index); setFeedback(''); };
  const selectLevel = (n: number) => { setLevel(n); setChallengeOffset(0); setSelected(null); setFeedback(''); };
  const nextChallenge = () => { setChallengeOffset((offset) => offset + 1); setSelected(null); setFeedback(''); };
  const pronounce = (item: LetterItem) => speak(item.letter, lang.locale);
  const levelTitle = language === 'ar' ? levelDetails[level].title : language === 'en' ? levelDetails[level].titleEn : levelDetails[level].titleFr;
  return <main className="site-shell content-page learn-page" dir="rtl">
    <Seo page="/learn" />
    <section className="page-intro learn-intro"><div><span className="eyebrow"><Languages size={15} /> تعلّم بطريقتك</span><h1>كل حرف يفتح باباً</h1><p>مسارات صغيرة في العربية والإنجليزية والفرنسية، مصمّمة لتكبر مع فضولك.</p></div><div className="learn-spark"><BookOpen size={40} /><span>تعلم في<br />وقتك</span></div></section>
    <section className="language-tabs" aria-label="اختر لغة التعلّم">{langs.map((item) => <button key={item.id} onClick={() => selectLanguage(item.id)} className={`language-tab ${language === item.id ? 'active' : ''}`} aria-pressed={language === item.id} data-testid={`button-language-${item.id}`}><span className="language-mark">{item.id === 'ar' ? 'ع' : item.id === 'en' ? 'A' : 'É'}</span><span>{item.label}</span></button>)}</section>
    <section className="path-heading"><div><span className="path-overline">مسار {lang.label}</span><h2>{lang.name}</h2><p>{lang.description}</p></div><div className="path-earned" data-testid="text-learning-stars"><Star size={20} fill="currentColor" /> {completed.length} / 6 مستويات</div></section>
     <section className="level-rail" aria-label="مستويات التعلّم">{levelDetails.map((item, i) => <button key={i} className={`level-step ${level === i ? 'current' : ''} ${completed.includes(i) ? 'done' : ''}`} onClick={() => selectLevel(i)} aria-current={level === i ? 'step' : undefined} data-testid={`button-level-${i}`}><span className="level-dot">{completed.includes(i) ? <CheckCircle2 size={18} /> : i}</span><span className="level-name">{language === 'ar' ? item.title : language === 'en' ? item.titleEn : item.titleFr}</span><small>{completed.includes(i) ? 'مكتمل' : 'متاح'}</small></button>)}</section>
    <section className="lesson-card" data-testid={`panel-level-${level}`}>
       <div className="lesson-main"><div className="lesson-label">المستوى {level} · مناسب لعمر 5–9</div><h2>{levelTitle}</h2><p>{levelDetails[level].text}</p>
         <div className="lesson-challenge"><span className="challenge-kicker">تحدّي صغير</span><h3>{level === 1 ? `ما الحرف الذي يأتي بعد ${currentLetter.letter}؟` : level === 3 ? `أي كلمة تبدأ بالحرف ${currentLetter.letter}؟` : level >= 4 ? reading.question : levelDetails[level].activity}</h3>
          {level === 2 && <button className="listen-prompt" onClick={() => speak(currentLetter.letter, lang.locale)} aria-label="استمع إلى صوت الحرف" data-testid="button-hear-learning-letter"><Headphones size={18} /> استمع للصوت</button>}
           {level === 4 && <p className="phrase-sample" lang={language} dir={language === 'ar' ? 'rtl' : 'ltr'}>{reading.sentence}</p>}
           {level === 5 && <div className="phrase-sample mastery-sample" lang={language} dir={language === 'ar' ? 'rtl' : 'ltr'}>{reading.sentence}<button onClick={() => speak(reading.sentence, lang.locale)} aria-label="استمع إلى الجملة" data-testid="button-speak-phrase"><Volume2 size={18} /></button></div>}
           <div className="learning-choices">{choices.map((value, i) => <button key={`${value}-${i}`} className={`learning-option ${selected === i ? 'selected' : ''} ${feedback.includes('أحسنت') && value === answer ? 'correct' : ''}`} onClick={() => pick(i)} lang={level >= 4 ? 'ar' : language} dir={level >= 4 || language === 'ar' ? 'rtl' : 'ltr'} data-testid={`button-learning-choice-${i}`}>{level < 3 && language === 'ar' ? <><span>{value}</span><small>{letters.find((l) => l.letter === value)?.word}</small></> : value}</button>)}</div>
          <button className="primary-action lesson-submit" onClick={finish} disabled={selected === null} data-testid="button-submit-learning">تحقّق من إجابتي <ArrowLeft size={17} /></button>
           <button className="icon-action lesson-submit" onClick={nextChallenge} data-testid="button-next-learning-challenge"><RefreshCw size={16} /> تحدٍّ جديد</button>
          <p className={`learning-feedback ${feedback.includes('أحسنت') ? 'positive' : ''}`} role="status" aria-live="polite" data-testid="status-learning-feedback">{feedback || 'اختر إجابة ثم تحقّق منها.'}</p>
        </div>
      </div>
      <aside className="letter-aside"><span className="letter-aside-label">حرف اليوم</span><button className="big-letter" onClick={() => pronounce(currentLetter)} aria-label={`استمع إلى الحرف ${currentLetter.letter}`} data-testid="button-pronounce-current">{currentLetter.letter}<Volume2 size={21} /></button><strong lang={language} dir={language === 'ar' ? 'rtl' : 'ltr'}>{currentLetter.word}</strong><small>{language === 'ar' ? `كلمة تبدأ بحرف ${currentLetter.letter}` : currentLetter.meaning || 'A word to discover'}</small></aside>
    </section>
    <section className="alphabet-section"><div className="alphabet-heading"><div><span className="path-overline">أبجدية كاملة</span><h2>كل الحروف في مكان واحد</h2><p>المس أي حرف للاستماع إلى نطقه ومشاهدة مثال بسيط.</p></div><span>{letters.length} حرفاً</span></div><div className={`alphabet-grid ${language !== 'ar' ? 'latin-grid' : ''}`} data-testid={`grid-alphabet-${language}`}>{letters.map((item, i) => <button key={`${item.letter}-${i}`} onClick={() => pronounce(item)} className="alphabet-card" lang={language} dir={language === 'ar' ? 'rtl' : 'ltr'} aria-label={`استمع إلى ${item.letter}، ${item.word}`} data-testid={`button-letter-${language}-${i}`}><strong>{item.letter}</strong><span>{item.word}</span></button>)}</div></section>
    <AdSlot slot="learn" />
  </main>;
}
