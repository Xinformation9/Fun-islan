import Seo from '@/components/Seo';
import AdSlot from '@/components/AdSlot';
import { useEffect, useMemo, useRef, useState } from 'react';
import { BookOpen, Headphones, Pause, Search, X } from 'lucide-react';

type Story = { id: string; title: string; age: string; topic: string; minutes: number; paragraphs: string[]; choices?: { prompt: string; options: { label: string; ending: string[] }[] } };
const stories: Story[] = [
  { id: 'seed', title: 'حبة القمح التي أرادت السفر', age: '5–6', topic: 'الطبيعة', minutes: 2, paragraphs: ['في صباح ربيعي، وجدت ليلى حبة قمح صغيرة قرب الحقل. وضعتها في كفها، فسمعتها تهمس: «أريد أن أرى العالم!» ابتسمت ليلى وقالت: «سأساعدك على بدء رحلتك».', 'حفرت حفرة صغيرة في التراب، ووضعت الحبة فيها، ثم سقتها برفق. في اليوم التالي لم ترَ شيئاً، لكنها عادت كل صباح تحمل الماء. وبعد أيام، ظهر طرف أخضر صغير كأنه يلوّح لها.', 'كبرت النبتة، وصارت سنبلة ذهبية مليئة بحبات القمح. ساعدت ليلى أسرتها على جمعها، ثم خبزوا رغيفاً دافئاً وتقاسموه مع الجيران.', 'قالت الحبة في سرّها: «وصلت إلى بيوت كثيرة، لأن أحداً اعتنى بي أولاً». وعرفت ليلى أن بعض الرحلات الجميلة تبدأ بهدوء، وبقلب يحب أن يساعد.'] },
  { id: 'cloud', title: 'غيمة تبحث عن لونها', age: '5–6', topic: 'المشاعر', minutes: 2, paragraphs: ['كانت غيمة بيضاء صغيرة تتأمل ألوان قوس قزح، وتتمنى أن يكون لها لون خاص. سألت نفسها: «ما اللون الذي يشبهني؟» لكن الريح حملتها بعيداً قبل أن تجد جواباً.', 'مرّت فوق البحر، فأهدتها الأمواج زرقة هادئة. ثم حلّقت فوق شجرة ليمون، فأعارتها الأوراق لمعة خضراء. وعندما وصلت إلى حديقة، انعكس عليها لون زهرة وردية، فصارت الغيمة تلمع بألوان كثيرة.', 'ضحكت الغيمة وقالت: «لوني هو كل الألوان التي شاركني بها أصدقائي!» رأت نبتة صغيرة عطشى، فأرسلت إليها قطرات مطر رقيقة.', 'رفعت النبتة أوراقها شاكرة، وشعرت الغيمة بالفرح. لم تعد تبحث عن لون واحد؛ فقد اكتشفت أن اختلاف الألوان يجعل السماء أجمل.'] },
  { id: 'lighthouse', title: 'مصباح الميناء الصغير', age: '7–9', topic: 'الشجاعة', minutes: 3, paragraphs: ['على طرف الميناء وقف مصباح صغير اسمه فِراس. كل مساء كان يضيء ممشى القوارب، لكنه كان يظن أن نوره أضعف من نور المنارة العالية.', 'في ليلة شتوية، غطّى الضباب البحر، ثم انطفأ ضوء المنارة فجأة. أخذت قوارب الصيادين تبحث عن طريق العودة. شعر فراس بالخوف، لكنه تذكر أن المراكب تحتاج إلى علامة ترشدها.', 'أضاء فراس بكل ما لديه، وثبّت شعاعه نحو الميناء. لاحظت القوارب الضوء الصغير، فسارت خلفه حتى وصلت إلى الشاطئ بأمان. أرسل القبطان رسالة شكر، وصفّق أهل الميناء للمصباح.', 'قال القبطان: «لم يكن نورك الأكبر، لكنه وصل في الوقت المناسب». ابتسم فراس، وعرف أن الشجاعة لا تعني ألا نخاف؛ بل أن نستخدم ما نستطيع لمساعدة الآخرين.'] },
  { id: 'turtle', title: 'سلحفاة وساعة الرمل', age: '5–6', topic: 'الصداقة', minutes: 2, paragraphs: ['كانت سلمى السلحفاة تتمنى أن تصل إلى شجرة التوت قبل أصدقائها السريعين. في كل مرة تنظر إلى آثار أقدامهم البعيدة، كانت تسرع ثم تتعب.', 'وجدت ساعة رملية عند الطريق. قالت لها العصفورة: «لا تقيسي يومك بسرعة غيرك؛ خذي وقتك، فالخطوات الصغيرة توصلك أيضاً». شكرت سلمى العصفورة، وتابعت السير بهدوء.', 'في الطريق رأت خنفساء عالقة تحت ورقة كبيرة. توقفت سلمى ودفعت الورقة حتى تحررت الخنفساء. ثم مشتا معاً نحو الشجرة، خطوة بعد خطوة.', 'عندما وصلتا، كان الأصدقاء قد تركوا لهما أحلى حبات التوت. قالت سلمى: «وصلت متأخرة قليلاً، لكنني وصلت ومعي صديقة جديدة». وضحك الجميع وتقاسموا الثمار.'] },
  { id: 'kite', title: 'طائرة نور الورقية', age: '7–9', topic: 'الشجاعة', minutes: 3, paragraphs: ['صنعت نور طائرة ورقية زرقاء، لكنها خافت أن تطلقها في يوم عاصف. كانت الريح تحرك الأشجار، فجلست قرب النافذة تراقبها.', 'سألت أباها: «هل أجرّب؟» قال: «نختار مكاناً واسعاً بعيداً عن الطريق، ونربط الخيط جيداً. وإذا اشتدت الريح نعود إلى البيت». طلبت نور من أخيها أن يساعدها، وأخذا الطائرة إلى الحديقة المفتوحة.', 'ركضت نور قليلاً، فارتفعت الطائرة فوق العشب ورقص ذيلها في الهواء. أمسكت بالخيط بكلتا يديها، وأخبرت أخاها عندما شعرت أن الريح قوية. ساعدها على لف الخيط، ثم انتظرا حتى هدأت.', 'قالت نور: «لم تختفِ الريح، لكنني تعلمت كيف أستعد لها». فهمت أن الشجاعة ليست أن نتجاهل الخطر، بل أن نتعلم ونجرب بأمان ونطلب المساعدة عند الحاجة.'] },
  { id: 'island', title: 'الجزيرة التي قالت نعم', age: '7–9', topic: 'اختيارات', minutes: 3, paragraphs: ['في جزيرة صغيرة، وجد سامر صندوقاً خشبياً قرب النبع. عليه ثلاث علامات: ريشة، وبذرة، ومفتاح. سمع همسة تقول: «اختر شيئاً واحداً، ثم اكتشف إلى أين يقودك».', 'جلس سامر يفكر. أراد أن يختار بسرعة، لكنه تذكر أن كل اختيار يفتح حكاية مختلفة. وضع يده على الصندوق، وتخيل أنه يستطيع العودة ليحكي لأصدقائه ما حدث.'], choices: { prompt: 'ماذا يختار سامر؟', options: [
    { label: 'الريشة الخفيفة', ending: ['أخذ سامر الريشة. قادته النسمة إلى عش عصفور صغير سقطت منه ريشة جناحه.', 'ثبتها العصفور في مكانها ورفرف فرحاً. عاد سامر إلى القرية وهو يحمل حكاية عن اللطف الذي يطير بعيداً.'] },
    { label: 'البذرة الذهبية', ending: ['اختار سامر البذرة وزرعها قرب النبع. مرّت الفصول، وصارت شجرة تمنح الظل لكل عابر.', 'عرف سامر أن الأشياء الصغيرة قد تكبر حين نعتني بها.'] },
    { label: 'المفتاح النحاسي', ending: ['فتح سامر باباً صغيراً في الصخرة، فوجد خرائط للجزيرة رسمها أطفال قدامى.', 'أضاف سامر طريقاً آمناً إلى الخريطة، وأعادها لتساعد من يأتي بعده.'] },
  ] } },
  { id: 'boat', title: 'قارب من ورق أزرق', age: '5–6', topic: 'الصداقة', minutes: 2, paragraphs: ['طيّ آدم ورقة زرقاء وصنع منها قارباً صغيراً. حمله إلى بركة الحديقة، ووضعه على الماء. دار القارب في مكانه، فضحك آدم وقال: «يبدو أنه يحتاج إلى فكرة جديدة».', 'جاءت مريم ومعها ورقة صفراء. رسمت شراعاً صغيراً، وساعدها آدم على تثبيته بعود خفيف. انتظرا هبوب النسيم، لكن الهواء كان ساكناً.', 'نفخ الصديقان برفق، فتحرك القارب نحو الضفة. سار كل واحد منهما إلى جانب الماء حتى وصلا إليه معاً. لم يكن هناك فائز، فكل طفل صنع قارباً، ثم تبادلا الحكايات والضحكات.', 'قال آدم: «معاً نصل أبعد». ومنذ ذلك اليوم، كلما واجهتهما مشكلة، بدأ كل واحد بفكرته ثم جمعا الفكرتين.'] },
];

function readingTime(minutes: number) {
  if (minutes === 1) return 'دقيقة واحدة';
  if (minutes === 2) return 'دقيقتان';
  return `${minutes} دقائق`;
}

export default function StoriesPage() {
  const [age, setAge] = useState('الكل'); const [topic, setTopic] = useState('الكل'); const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<Story | null>(null); const [choice, setChoice] = useState<number | null>(null); const [speaking, setSpeaking] = useState(false);
  const readerRef = useRef<HTMLElement>(null);
  const list = useMemo(() => stories.filter((s) => (age === 'الكل' || s.age === age) && (topic === 'الكل' || s.topic === topic) && s.title.includes(query.trim())), [age, topic, query]);
  useEffect(() => {
    if (!selected) return;
    readerRef.current?.focus();
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') { window.speechSynthesis?.cancel(); setSpeaking(false); setSelected(null); setChoice(null); } };
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, [selected]);
  const stop = () => { window.speechSynthesis?.cancel(); setSpeaking(false); };
  const speak = () => {
    if (!selected || !('speechSynthesis' in window)) return;
    stop(); const text = [...selected.paragraphs, ...(choice !== null && selected.choices ? selected.choices.options[choice].ending : [])].join(' ');
    const utterance = new SpeechSynthesisUtterance(text); utterance.lang = 'ar-SA'; utterance.onend = () => setSpeaking(false); utterance.onerror = () => setSpeaking(false); setSpeaking(true); window.speechSynthesis.speak(utterance);
  };
  const close = () => { stop(); setSelected(null); setChoice(null); };
  return <main className="site-shell content-page" dir="rtl">
    <Seo page="/stories" />
    <section className="page-intro stories-intro"><div><span className="eyebrow"><BookOpen size={15} /> حكايات من الجزيرة</span><h1>افتح كتاباً… وسافر</h1><p>قصص قصيرة أصلية للقراءة معاً أو الاستماع إليها بصوت الجهاز.</p></div><div className="story-count"><strong>٧</strong><span>حكايات تنتظرك</span></div></section>
    <section className="story-library">
      <div className="filter-row"><label className="searchbox story-search"><Search size={18} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث عن قصة" aria-label="ابحث عن قصة" data-testid="input-search-stories" /></label>
        <label>العمر <select value={age} onChange={(e) => setAge(e.target.value)} data-testid="select-story-age"><option>الكل</option><option>5–6</option><option>7–9</option></select></label>
        <label>الموضوع <select value={topic} onChange={(e) => setTopic(e.target.value)} data-testid="select-story-topic"><option>الكل</option>{['الطبيعة', 'المشاعر', 'الشجاعة', 'الصداقة', 'اختيارات'].map((v) => <option key={v}>{v}</option>)}</select></label>
      </div>
      <div className="stories-grid" data-testid="grid-stories">{list.map((story, i) => <article className={`story-card story-tone-${i % 4}`} key={story.id} data-testid={`card-story-${story.id}`}>
        <div className="story-art" aria-hidden="true"><span>{['ق', 'غ', 'م', 'س'][i % 4]}</span><small>{story.topic}</small></div><div className="story-card-copy"><div className="story-meta"><span>{story.age} سنوات</span><span>{readingTime(story.minutes)}</span></div><h2>{story.title}</h2><p>{story.paragraphs[0]}</p><button className="text-action" onClick={() => { setSelected(story); setChoice(null); }} data-testid={`button-read-${story.id}`}>اقرأ الحكاية <span aria-hidden="true">←</span></button></div>
      </article>)}</div>
      {list.length === 0 && <div className="state-panel" data-testid="status-no-stories"><BookOpen size={30} /><h3>لم نجد قصة بهذا الوصف</h3><p>غيّر كلمات البحث أو اختر موضوعاً آخر.</p><button className="retry-button" onClick={() => { setQuery(''); setAge('الكل'); setTopic('الكل'); }} data-testid="button-reset-story-filters">عرض كل القصص</button></div>}
    </section>
    {selected && <div className="reader-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) close(); }}><section ref={readerRef} tabIndex={-1} className="reader-panel" role="dialog" aria-modal="true" aria-labelledby="reader-title" dir="rtl" data-testid="dialog-story-reader">
       <div className="reader-tools"><span><BookOpen size={16} /> قراءة هادئة · {readingTime(selected.minutes)}</span><div><button className="icon-action" onClick={speaking ? stop : speak} aria-label={speaking ? 'إيقاف السرد' : 'استمع إلى القصة'} data-testid="button-story-speech">{speaking ? <Pause size={18} /> : <Headphones size={18} />}{speaking ? 'إيقاف' : 'استمع'}</button><button className="reader-close" onClick={close} aria-label="إغلاق القصة" data-testid="button-close-story"><X size={20} /></button></div></div>
      <article className="reader-copy"><span className="reader-topic">{selected.topic} · مناسبة لعمر {selected.age}</span><h2 id="reader-title">{selected.title}</h2>{selected.paragraphs.map((p, i) => <p key={i}>{p}</p>)}
      {selected.choices && <div className="story-choice"><h3>{selected.choices.prompt}</h3><div className="choice-row">{selected.choices.options.map((option, i) => <button key={option.label} className={`answer-tile ${choice === i ? 'chosen' : ''}`} onClick={() => setChoice(i)} data-testid={`button-story-choice-${i}`}>{option.label}</button>)}</div>{choice !== null && <div className="story-ending" aria-live="polite">{selected.choices.options[choice].ending.map((p, i) => <p key={i}>{p}</p>)}</div>}</div>}
      </article>
    </section></div>}
    <AdSlot slot="stories" />
  </main>;
}
