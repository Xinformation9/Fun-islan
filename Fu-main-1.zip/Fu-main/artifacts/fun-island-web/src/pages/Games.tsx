import Seo from '@/components/Seo';
import { useEffect, useState } from 'react';
import { ChevronDown, RotateCcw, Star } from 'lucide-react';

type GameId = 'memory' | 'match' | 'maze' | 'count' | 'build';
const games: { id: GameId; title: string; intro: string; badge: string }[] = [
  { id: 'memory', title: 'ذاكرة الجزيرة', intro: 'اقلب البطاقات وابحث عن كل زوج متشابه.', badge: 'تذكّر' },
  { id: 'match', title: 'حرف وكلمة', intro: 'اختر الكلمة التي تبدأ بالحرف المعروض.', badge: 'حروف' },
  { id: 'maze', title: 'طريق الكنز', intro: 'حرّك المستكشف حتى يصل إلى النجمة.', badge: 'متاهة' },
  { id: 'count', title: 'عدّ الأصداف', intro: 'عدّ الأصداف ثم اختر الرقم الصحيح.', badge: 'أرقام' },
  { id: 'build', title: 'رتّب الحروف', intro: 'رتّب الحروف لتكوين اسم الصورة.', badge: 'كلمات' },
];
const pairs = ['قمر', 'سمكة', 'بيت', 'شمس', 'قمر', 'سمكة', 'بيت', 'شمس'];
const words = [{ letter: 'س', answer: 'سمكة', options: ['سمكة', 'قمر', 'بيت'] }, { letter: 'ب', answer: 'باب', options: ['موز', 'باب', 'نجم'] }, { letter: 'ق', answer: 'قمر', options: ['قمر', 'تفاح', 'زهرة'] }];
const builds = [{ word: 'قمر', letters: ['ر', 'ق', 'م'] }, { word: 'بيت', letters: ['ت', 'ب', 'ي'] }, { word: 'باب', letters: ['ا', 'ب', 'ب'] }];
const easyMaze = ['S..#.', '.#...', '...#.', '#....', '....G'];
const challengeMaze = ['S..#...', '.#.#.#.', '.#...#.', '...#...', '#.#...#', '...#...', '.#....G'];
const STORAGE = 'fun-island-games-v1';

function loadStars(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(STORAGE) || '{}') as Record<string, number>; } catch { return {}; }
}

export default function GamesPage() {
  const [active, setActive] = useState<GameId>('memory');
  const [age, setAge] = useState('5–6');
  const [stars, setStars] = useState<Record<string, number>>(loadStars);
  const [round, setRound] = useState(0);
  const [roundComplete, setRoundComplete] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [position, setPosition] = useState([0, 0]);
  const [countPick, setCountPick] = useState<number | null>(null);
  const [buildOrder, setBuildOrder] = useState<string[]>([]);
  const mazeMap = age === '5–6' ? easyMaze : challengeMaze;
  const current = games.find((g) => g.id === active)!;
  const activePairs = age === '5–6' ? [pairs[0], pairs[1], pairs[0], pairs[1]] : pairs;
  const complete = (message = 'أحسنت! أنجزت الجولة.') => {
    if (roundComplete) return;
    setRoundComplete(true);
    setFeedback(message);
    setStars((old) => { const next = { ...old, [active]: Math.min(5, (old[active] || 0) + 1) }; localStorage.setItem(STORAGE, JSON.stringify(next)); return next; });
  };
  const reset = () => { setRound((n) => n + 1); setRoundComplete(false); setFeedback(''); setFlipped([]); setMatched([]); setPosition([0, 0]); setCountPick(null); setBuildOrder([]); };
  const chooseGame = (id: GameId) => { setActive(id); reset(); };

  useEffect(() => {
    if (active !== 'maze' || feedback) return;
    const onKey = (event: KeyboardEvent) => {
      const keys: Record<string, [number, number]> = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, 1], ArrowRight: [0, -1], w: [-1, 0], s: [1, 0], a: [0, 1], d: [0, -1] };
      const delta = keys[event.key];
      if (delta) { event.preventDefault(); move(delta[0], delta[1]); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  function move(dr: number, dc: number) {
    const [r, c] = position;
    const nr = r + dr; const nc = c + dc;
    if (nr < 0 || nr >= mazeMap.length || nc < 0 || nc >= mazeMap[nr].length || mazeMap[nr][nc] === '#') return;
    setPosition([nr, nc]);
    if (mazeMap[nr][nc] === 'G') complete('وصلت إلى الكنز! نجمة جديدة لك.');
  }
  function flip(index: number) {
    if (flipped.length === 2 || flipped.includes(index) || matched.includes(index)) return;
    const next = [...flipped, index]; setFlipped(next);
    if (next.length === 2) {
      if (activePairs[next[0]] === activePairs[next[1]]) {
        const done = [...matched, ...next]; setMatched(done); setFlipped([]);
        if (done.length === activePairs.length) complete('وجدت كل الأزواج! ذاكرة رائعة.');
      } else { setFeedback('ليستا زوجاً هذه المرة. حاولي مجدداً!'); window.setTimeout(() => { setFlipped([]); setFeedback(''); }, 850); }
    }
  }
  const prompt = active === 'match' ? words[round % words.length] : null;
  const build = builds[round % builds.length];
  const count = (age === '5–6' ? [3, 4, 2] : [5, 7, 6])[round % 3];
  return <main className="site-shell content-page" dir="rtl">
    <Seo page="/games" />
    <section className="page-intro game-intro"><div><span className="eyebrow"><Star size={15} /> ركن اللعب الآمن</span><h1>ألعاب صغيرة، إنجازات كبيرة</h1><p>اختار لعبة، جرّب براحتك، واجمع نجومك في الجزيرة.</p></div><div className="score-stamp"><strong>{Object.values(stars).reduce((a, b) => a + b, 0)}</strong><span>نجمة جمعتها</span></div></section>
    <section className="game-layout">
      <aside className="game-sidebar" aria-label="اختيار لعبة"><label className="field-label">اختر العمر
        <select value={age} onChange={(e) => { setAge(e.target.value); reset(); }} data-testid="select-game-age"><option>5–6</option><option>7–9</option></select><ChevronDown size={16} aria-hidden="true" />
      </label><h2>جولات الجزيرة</h2>{games.map((game, i) => <button key={game.id} className={`game-choice ${active === game.id ? 'selected' : ''}`} onClick={() => chooseGame(game.id)} data-testid={`button-game-${game.id}`}>
        <span className="game-number">0{i + 1}</span><span className="game-choice-copy"><b>{game.title}</b><small>{game.badge} · {stars[game.id] || 0} نجوم</small></span><span aria-hidden="true">›</span>
      </button>)}</aside>
      <section className="game-board" aria-labelledby="game-title" data-testid={`game-panel-${active}`}>
        <div className="game-board-head"><div><span className="game-kicker">{current.badge} · العمر {age}</span><h2 id="game-title">{current.title}</h2><p>{current.intro}</p></div><button className="icon-action" onClick={reset} aria-label="ابدأ الجولة من جديد" data-testid="button-game-restart"><RotateCcw size={18} /><span>إعادة</span></button></div>
        <div className="play-area" key={`${active}-${round}`}>
          {active === 'memory' && <div className="memory-grid">{activePairs.map((word, i) => <button key={i} className={`memory-card ${flipped.includes(i) || matched.includes(i) ? 'revealed' : ''} ${matched.includes(i) ? 'paired' : ''}`} onClick={() => flip(i)} aria-label={flipped.includes(i) || matched.includes(i) ? word : `بطاقة مخفية ${i + 1}`} data-testid={`button-memory-card-${i}`}>{flipped.includes(i) || matched.includes(i) ? word : '؟'}</button>)}</div>}
          {active === 'match' && prompt && <div className="quiz-area"><div className="letter-prompt">{prompt.letter}</div><div className="choice-row">{prompt.options.map((option) => <button key={option} className="answer-tile" onClick={() => option === prompt.answer ? complete('صحيح! يبدأ بالحرف ' + prompt.letter) : setFeedback('جرّب كلمة أخرى تبدأ بهذا الحرف.')} data-testid={`button-word-${option}`}>{option}</button>)}</div></div>}
           {active === 'maze' && <div className="maze-wrap"><div className={`maze-grid ${age === '7–9' ? 'challenge' : ''}`} role="grid" aria-label="متاهة، استخدم الأسهم أو الأزرار للتحرك">{mazeMap.map((row, ri) => row.split('').map((cell, ci) => <div role="gridcell" key={`${ri}-${ci}`} className={`maze-cell ${cell === '#' ? 'wall' : ''} ${position[0] === ri && position[1] === ci ? 'traveler' : ''}`} aria-label={cell === 'G' ? 'الكنز' : cell === '#' ? 'جدار' : position[0] === ri && position[1] === ci ? 'المستكشف' : 'ممر'}>{position[0] === ri && position[1] === ci ? '●' : cell === 'G' ? '★' : ''}</div>))}</div><div className="maze-controls" aria-label="أزرار تحريك المتاهة"><button onClick={() => move(-1, 0)} aria-label="تحرك للأعلى" data-testid="button-maze-up">↑</button><div><button onClick={() => move(0, 1)} aria-label="تحرك لليسار" data-testid="button-maze-left">←</button><button onClick={() => move(1, 0)} aria-label="تحرك للأسفل" data-testid="button-maze-down">↓</button><button onClick={() => move(0, -1)} aria-label="تحرك لليمين" data-testid="button-maze-right">→</button></div></div><p className="hint">استخدم الأسهم على لوحة المفاتيح أو أزرار الحركة.</p></div>}
          {active === 'count' && <div className="count-area"><p className="count-question">كم صدفة على الشاطئ؟</p><div className="shells" aria-label={`${count} أصداف`}>{Array.from({ length: count }, (_, i) => <span key={i} className="shell-shape" aria-hidden="true">◒</span>)}</div><div className="choice-row">{[count - 1, count, count + 1].map((n) => <button key={n} className={`number-tile ${countPick === n ? 'chosen' : ''}`} onClick={() => { setCountPick(n); n === count ? complete('عددتها بشكل صحيح!') : setFeedback('عدّها مرة أخرى بهدوء.'); }} data-testid={`button-count-${n}`}>{n}</button>)}</div></div>}
          {active === 'build' && <div className="build-area"><div className="letter-prompt">{build.word === 'بيت' ? '⌂' : build.word}</div><p>المس الحروف بالترتيب الصحيح</p><div className="built-word" aria-live="polite">{buildOrder.length ? buildOrder.join('') : '＿ ＿ ＿'}</div><div className="choice-row">{build.letters.map((letter, i) => <button key={`${letter}${i}`} className="answer-tile" onClick={() => { const next = [...buildOrder, letter]; setBuildOrder(next); if (next.join('') === build.word) complete('أحسنت! رتّبت الكلمة.'); else if (next.length === build.word.length) { setFeedback('ليس هذا ترتيب الكلمة. ابدأ من جديد.'); setBuildOrder([]); } }} data-testid={`button-build-letter-${i}`}>{letter}</button>)}</div></div>}
        </div>
        <div className={`game-feedback ${feedback.includes('صحيح') || feedback.includes('أحسنت') || feedback.includes('نجمة') || feedback.includes('وصلت') || feedback.includes('رائعة') ? 'success' : ''}`} role="status" aria-live="polite" data-testid="status-game-feedback">{feedback || 'خذ وقتك — كل محاولة تساعدك على التعلّم.'}{feedback && (feedback.includes('صحيح') || feedback.includes('أحسنت') || feedback.includes('نجمة') || feedback.includes('وصلت') || feedback.includes('رائعة')) && <span className="earned-star"><Star size={17} fill="currentColor" /> +1</span>}</div>
        <div className="game-progress"><span>نجوم هذه اللعبة</span><div aria-label={`${stars[active] || 0} من 5 نجوم`}>{Array.from({ length: 5 }, (_, i) => <Star key={i} size={19} className={i < (stars[active] || 0) ? 'star-filled' : ''} fill={i < (stars[active] || 0) ? 'currentColor' : 'none'} />)}</div><span className="progress-note">كل إعادة فرصة لجمع نجمة جديدة</span></div>
      </section>
    </section>
  </main>;
}
