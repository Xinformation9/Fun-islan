import { useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useListChannelVideos } from '@workspace/api-client-react';
import type { YoutubeVideo } from '@workspace/api-client-react';
import coverImage from '@assets/cover_1793532475613.jpg';
import {
  ArrowDown,
  CalendarDays,
  ChevronDown,
  CircleAlert,
  Compass,
  Expand,
  Film,
  Play,
  Search,
  Sparkles,
  X,
} from 'lucide-react';
import { Link, Route, Router, Switch } from 'wouter';
import GamesPage from './pages/Games';
import StoriesPage from './pages/Stories';
import LearnPage from './pages/Learn';
import PrivacyPage from './pages/Privacy';
import IslandHeader from './components/IslandHeader';
import Seo from './components/Seo';
import AdSlot from './components/AdSlot';
import AmbientScene from './components/AmbientScene';
import ParentGate from './components/ParentGate';
import SiteFooter from './components/SiteFooter';
import HomeExtras from './components/HomeExtras';

const PAGE_SIZE = 12;
const queryClient = new QueryClient();

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat('ar', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(date);
}

function VideoCard({ video, onPlay }: { video: YoutubeVideo; onPlay: (video: YoutubeVideo) => void }) {
  return (
    <article className="video-card" data-testid={`card-video-${video.id}`}>
      <button
        className="thumb-button"
        onClick={() => onPlay(video)}
        aria-label={`شاهد: ${video.title}`}
        data-testid={`button-play-${video.id}`}
      >
        <img src={video.thumbnail} alt="" loading="lazy" />
        <span className="thumb-play" aria-hidden="true"><Play size={18} fill="currentColor" /></span>
      </button>
      <div className="card-copy">
        <h3 data-testid={`text-video-title-${video.id}`}>{video.title}</h3>
        <div className="card-meta">
          <span>{video.channelTitle}</span>
          <span dir="auto">{formatDate(video.publishedAt)}</span>
        </div>
      </div>
    </article>
  );
}

function VideoSkeleton() {
  return (
    <div className="video-grid" aria-label="جارٍ تحميل الفيديوهات" role="status" data-testid="status-loading">
      {Array.from({ length: 6 }, (_, index) => (
        <div className="skeleton" key={index} aria-hidden="true">
          <div className="skeleton-pic" />
          <div className="skeleton-line" />
          <div className="skeleton-line" style={{ width: '58%', marginTop: '-7px' }} />
        </div>
      ))}
    </div>
  );
}

function VideoLibrary() {
  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [pageToken, setPageToken] = useState<string | undefined>();
  const [videos, setVideos] = useState<YoutubeVideo[]>([]);
  const [activeVideo, setActiveVideo] = useState<YoutubeVideo | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const nextQuery = searchInput.trim();
    const timeout = window.setTimeout(() => {
      if (nextQuery === searchQuery) return;
      setVideos([]);
      setPageToken(undefined);
      setSearchQuery(nextQuery);
    }, 450);
    return () => window.clearTimeout(timeout);
  }, [searchInput, searchQuery]);

  const params = useMemo(() => ({
    maxResults: PAGE_SIZE,
    ...(searchQuery ? { query: searchQuery } : {}),
    ...(pageToken ? { pageToken } : {}),
  }), [searchQuery, pageToken]);

  const query = useListChannelVideos(params);

  useEffect(() => {
    if (query.isFetching || !query.data) return;
    const incoming = query.data.videos ?? [];
    if (!pageToken) {
      setVideos(incoming);
      return;
    }
    setVideos((current) => {
      const known = new Set(current.map((video) => video.id));
      return [...current, ...incoming.filter((video) => !known.has(video.id))];
    });
  }, [query.data, query.isFetching, pageToken]);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (activeVideo && !dialog.open) dialog.showModal();
    if (!activeVideo && dialog.open) dialog.close();
  }, [activeVideo]);

  const featured = videos[0];
  const remainingVideos = videos.slice(1);
  const hasSearch = searchQuery.length > 0;

  const playVideo = (video: YoutubeVideo) => setActiveVideo(video);
  const closePlayer = () => {
    if (dialogRef.current?.open) dialogRef.current.close();
    setActiveVideo(null);
  };
  const loadMore = () => {
    if (query.data?.nextPageToken && !query.isFetching) setPageToken(query.data.nextPageToken);
  };
  const retry = () => { void query.refetch(); };
  const enterFullscreen = () => {
    const target = playerRef.current;
    if (target?.requestFullscreen) void target.requestFullscreen();
  };

  return (
    <div dir="rtl" className="min-h-[100dvh]">
      <Seo page="/" />
      <main className="site-shell">
        <section className="hero" aria-labelledby="hero-title" data-testid="section-welcome">
          <img className="cover" src={coverImage} alt="أهلاً بكم في جزيرة المرح" />
          <div className="hero-copy">
            <span className="eyebrow"><Sparkles size={15} /> حكاية جديدة كل أسبوع</span>
            <h1 id="hero-title">أهلاً بكم في جزيرتنا!</h1>
            <p>مكان يجتمع فيه الصغار والكبار لاكتشاف قصص ممتعة وتعلّم أشياء جديدة.</p>
          </div>
          <div className="hero-scroll" aria-hidden="true">اكتشف المكتبة <ChevronDown size={16} /></div>
        </section>

        <section className="library" aria-labelledby="library-title">
          <div className="section-head">
            <div className="section-title">
              <span className="section-mark" aria-hidden="true"><Compass size={21} /></span>
              <div>
                <h2 id="library-title">مكتبة جزيرة المرح</h2>
                <p>اختاروا حكايتكم القادمة وشاهدوها معاً</p>
              </div>
            </div>
            <label className="searchbox">
              <Search size={19} aria-hidden="true" />
              <input
                type="search"
                value={searchInput}
                onChange={(event) => setSearchInput(event.target.value)}
                placeholder="ابحثوا عن حكاية..."
                aria-label="ابحثوا عن فيديو"
                data-testid="input-search-videos"
              />
            </label>
          </div>

          {query.isLoading && videos.length === 0 ? (
            <>
              <div className="featured-label"><Sparkles size={16} /> أحدث حكاية وصلت إلى الجزيرة</div>
              <div className="skeleton" aria-hidden="true"><div className="skeleton-pic" style={{ aspectRatio: '2.1/1' }} /><div className="skeleton-line" /></div>
              <VideoSkeleton />
            </>
          ) : query.isError && videos.length === 0 ? (
            <div className="state-panel" role="alert" data-testid="status-load-error">
              <CircleAlert size={32} aria-hidden="true" />
              <h3>تعذّر تحميل الحكايات</h3>
              <p>يبدو أن الجزيرة بعيدة قليلاً الآن. حاولوا مرة أخرى بعد لحظة.</p>
              <button className="retry-button" onClick={retry} data-testid="button-retry-videos">إعادة المحاولة</button>
            </div>
          ) : videos.length === 0 ? (
            <div className="state-panel" data-testid="status-empty-videos">
              <Film size={34} aria-hidden="true" />
              <h3>{hasSearch ? 'لم نعثر على هذه الحكاية' : 'لا توجد حكايات هنا بعد'}</h3>
              <p>{hasSearch ? 'جرّبوا كلمة أخرى للبحث في فيديوهات القناة.' : 'ستظهر أحدث فيديوهات القناة هنا قريباً.'}</p>
              {hasSearch && <button className="retry-button" onClick={() => { setSearchInput(''); setSearchQuery(''); }} data-testid="button-clear-search">عرض كل الحكايات</button>}
            </div>
          ) : (
            <>
              <div className="featured-label" data-testid="label-featured"><Sparkles size={16} /> أحدث حكاية وصلت إلى الجزيرة</div>
              {featured && (
                <article className="featured" data-testid={`featured-video-${featured.id}`}>
                  <button className="featured-media" onClick={() => playVideo(featured)} aria-label={`شاهد أحدث فيديو: ${featured.title}`} data-testid={`button-play-featured-${featured.id}`}>
                    <img src={featured.thumbnail} alt="" />
                    <span className="play-disc" aria-hidden="true"><Play size={27} fill="currentColor" /></span>
                  </button>
                  <div className="featured-copy">
                    <span className="latest-pill">وصلت للتو</span>
                    <h3 data-testid={`text-featured-title-${featured.id}`}>{featured.title}</h3>
                    <p>{featured.description || 'اكتشفوا هذه الحكاية الجديدة معاً في جزيرة المرح.'}</p>
                    <div className="meta-line"><CalendarDays size={15} /> <span dir="auto">{formatDate(featured.publishedAt)}</span></div>
                    <button className="watch-button" onClick={() => playVideo(featured)} data-testid={`button-watch-featured-${featured.id}`}>
                      <Play size={17} fill="currentColor" /> شاهدوا الحكاية
                    </button>
                  </div>
                </article>
              )}

              <div className="browse-head">
                <h2>{hasSearch ? 'نتائج البحث' : 'حكايات أخرى'}</h2>
                <span data-testid="text-video-count">{videos.length} فيديو</span>
              </div>
              {remainingVideos.length > 0 ? (
                <div className="video-grid" data-testid="grid-videos">
                  {remainingVideos.map((video) => <VideoCard key={video.id} video={video} onPlay={playVideo} />)}
                </div>
              ) : !query.data?.nextPageToken ? (
                <div className="state-panel" data-testid="status-no-more-videos">
                  <Film size={26} aria-hidden="true" />
                  <p>هذه أحدث حكاية في المكتبة. استمتعوا بالمشاهدة معاً!</p>
                </div>
              ) : null}

              {query.data?.nextPageToken && (
                <div className="load-more-wrap">
                  <button className="load-more" onClick={loadMore} disabled={query.isFetching} data-testid="button-load-more">
                    {query.isFetching ? 'جارٍ تحميل المزيد...' : <>حكايات أكثر <ArrowDown size={17} /></>}
                  </button>
                </div>
              )}
              {query.isError && videos.length > 0 && (
                <div className="state-panel" role="alert" data-testid="status-more-error">
                  <p>لم نتمكن من تحميل المزيد من الحكايات.</p>
                  <button className="retry-button" onClick={retry} data-testid="button-retry-more">حاولوا مجدداً</button>
                </div>
              )}
            </>
          )}
        </section>
        <AdSlot slot="home" />
        <HomeExtras />
      </main>

      <dialog
        className="player-dialog"
        ref={dialogRef}
        aria-label={activeVideo ? `مشاهدة ${activeVideo.title}` : 'مشغل الفيديو'}
        onClick={(event) => { if (event.target === dialogRef.current) closePlayer(); }}
        onClose={() => setActiveVideo(null)}
        data-testid="dialog-video-player"
      >
        {activeVideo && (
          <>
            <div className="player-head">
              <p className="player-title">{activeVideo.title}</p>
              <div className="player-actions">
                <button onClick={enterFullscreen} aria-label="ملء الشاشة" title="ملء الشاشة" data-testid="button-player-fullscreen"><Expand size={18} /></button>
                <button onClick={closePlayer} aria-label="إغلاق المشغل" title="إغلاق" data-testid="button-player-close"><X size={19} /></button>
              </div>
            </div>
            <div className="player-frame" ref={playerRef}>
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(activeVideo.id)}?autoplay=1&controls=1&rel=0`}
                title={activeVideo.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                data-testid="iframe-video-player"
              />
            </div>
          </>
        )}
      </dialog>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <AmbientScene />
        <ParentGate />
        <IslandHeader />
        <Switch>
          <Route path="/" component={VideoLibrary} />
          <Route path="/games" component={GamesPage} />
          <Route path="/stories" component={StoriesPage} />
          <Route path="/learn" component={LearnPage} />
          <Route path="/privacy" component={PrivacyPage} />
          <Route component={NotFound} />
        </Switch>
        <SiteFooter />
      </Router>
    </QueryClientProvider>
  );
}

function NotFound() {
  return <main className="site-shell content-page"><section className="state-panel"><h1>هذه الجزيرة غير موجودة</h1><p>لنعد إلى مكان نعرفه.</p><Link href="/" className="primary-action" data-testid="link-not-found-home">العودة إلى المكتبة</Link></section></main>;
}

export default App;
