import { useEffect } from 'react';
import { CRUMBS, FAQ, PAGES, SITE } from '@/lib/site';

function setMeta(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) { el = document.createElement('meta'); el.setAttribute(attr, key); document.head.appendChild(el); }
  el.setAttribute('content', content);
}

export default function Seo({ page }: { page: keyof typeof PAGES }) {
  useEffect(() => {
    const { title, desc } = PAGES[page];
    const origin = window.location.origin;
    const base = import.meta.env.BASE_URL.replace(/\/$/, '');
    const url = origin + base + (page === '/' ? '/' : page);
    document.title = title;
    setMeta('name', 'description', desc);
    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', desc);
    setMeta('property', 'og:url', url);
    setMeta('property', 'og:image', `${origin}${base}/og-cover.jpg`);
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', desc);
    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) { link = document.createElement('link'); link.rel = 'canonical'; document.head.appendChild(link); }
    link.href = url;

    const graph: Record<string, unknown>[] = [{
      '@type': page === '/learn' ? ['WebPage', 'LearningResource'] : 'WebPage',
      '@id': `${url}#page`, url, name: title, description: desc, inLanguage: 'ar',
      isPartOf: { '@id': `${origin}${base}/#site` },
      audience: { '@type': 'PeopleAudience', suggestedMinAge: 5, suggestedMaxAge: 9 },
      publisher: { '@type': 'Organization', name: SITE.name, sameAs: [SITE.yt, SITE.fb, SITE.tt] },
    }];
    if (CRUMBS[page]) {
      graph.push({ '@type': 'BreadcrumbList', itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'المكتبة', item: `${origin}${base}/` },
        { '@type': 'ListItem', position: 2, name: CRUMBS[page], item: url },
      ] });
    }
    if (page === '/') {
      graph.push({ '@type': 'FAQPage', mainEntity: FAQ.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) });
    }
    const ld = document.createElement('script');
    ld.type = 'application/ld+json';
    ld.id = 'ld-page';
    ld.text = JSON.stringify({ '@context': 'https://schema.org', '@graph': graph });
    document.getElementById('ld-page')?.remove();
    document.head.appendChild(ld);
    return () => ld.remove();
  }, [page]);
  return null;
}
