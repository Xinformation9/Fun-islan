import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';

const SOCIAL = /(youtube\.com\/@|facebook\.com|tiktok\.com)/;

/** Asks a simple parent question before opening YouTube / Facebook / TikTok profile links. */
export default function ParentGate() {
  const ref = useRef<HTMLDialogElement>(null);
  const [target, setTarget] = useState<string | null>(null);
  const [nums, setNums] = useState<[number, number]>([2, 3]);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState(false);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const link = (e.target as Element | null)?.closest?.('a[href]') as HTMLAnchorElement | null;
      if (!link || !SOCIAL.test(link.href) || typeof ref.current?.showModal !== 'function') return;
      e.preventDefault();
      setNums([2 + Math.floor(Math.random() * 7), 3 + Math.floor(Math.random() * 6)]);
      setAnswer(''); setError(false); setTarget(link.href);
    };
    document.addEventListener('click', onClick);
    return () => document.removeEventListener('click', onClick);
  }, []);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (target && !d.open) d.showModal();
    if (!target && d.open) d.close();
  }, [target]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (Number(answer) === nums[0] + nums[1] && target) { window.open(target, '_blank', 'noopener,noreferrer'); setTarget(null); }
    else setError(true);
  };

  return <dialog ref={ref} className="gate" aria-labelledby="gate-title" onClose={() => setTarget(null)}>
    <form onSubmit={submit}>
      <h2 id="gate-title">🔒 للأهل فقط</h2>
      <p>هذا الرابط يفتح موقعاً خارجياً. للمتابعة، كم حاصل {nums[0]} + {nums[1]}؟</p>
      <input inputMode="numeric" autoComplete="off" aria-label="الإجابة" value={answer} onChange={(e) => setAnswer(e.target.value)} />
      <div className="gate-actions">
        <button type="submit" className="primary-action">متابعة</button>
        <button type="button" className="retry-button" onClick={() => setTarget(null)}>إلغاء</button>
      </div>
      {error && <p className="gate-err" role="alert">إجابة غير صحيحة، حاول مرة أخرى</p>}
    </form>
  </dialog>;
}
