import { SITE } from '@/lib/site';

const items = [
  { cls: 'yt', href: `${SITE.yt}?sub_confirmation=1`, row: 'يوتيوب', card: 'اشترك في يوتيوب', sub: '@funisland9090', icon: <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="1" y="5" width="22" height="14" rx="4" fill="currentColor" /><path d="M10 9l5 3-5 3z" fill="#fff" /></svg> },
  { cls: 'fb', href: SITE.fb, row: 'فيسبوك', card: 'تابعنا على فيسبوك', sub: 'جزيرة المرح', icon: <b aria-hidden="true">f</b> },
  { cls: 'tt', href: SITE.tt, row: 'تيك توك', card: 'تابعنا على تيك توك', sub: '@fun.island42', icon: <b aria-hidden="true">♪</b> },
];

export default function SocialLinks({ variant }: { variant: 'row' | 'cards' }) {
  return <div className={variant === 'row' ? 'social-row' : 'follow-grid'}>
    {items.map((s) => <a key={s.cls} className={`soc ${s.cls}`} href={s.href} target="_blank" rel="noopener noreferrer" data-testid={`link-social-${s.cls}`}>
      {s.icon}<span>{variant === 'row' ? s.row : s.card}{variant === 'cards' && <small>{s.sub}</small>}</span>
    </a>)}
  </div>;
}
