import { FAQ } from '@/lib/site';
import SocialLinks from './SocialLinks';

export default function HomeExtras() {
  return <>
    <section className="faq" aria-labelledby="faq-title">
      <h2 id="faq-title" className="extras-title">أسئلة شائعة من الأهل</h2>
      <div className="faq-list">
        {FAQ.map(([q, a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}
      </div>
    </section>
    <section className="follow" aria-labelledby="follow-title">
      <h2 id="follow-title" className="extras-title">تابع جزيرة المرح واشترك</h2>
      <p className="follow-lead">فيديوهات وقصص وأغانٍ جديدة على منصاتنا. ننصح الأهل بالمتابعة مع الطفل.</p>
      <SocialLinks variant="cards" />
    </section>
  </>;
}
