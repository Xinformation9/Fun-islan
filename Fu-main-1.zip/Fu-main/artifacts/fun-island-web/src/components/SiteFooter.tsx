import { Link } from 'wouter';
import channelLogo from '@assets/logo_1793532475854.png';
import SocialLinks from './SocialLinks';
import { ADS } from '@/lib/site';

export default function SiteFooter() {
  return <footer className="site-shell footer-wrap" dir="rtl">
    <SocialLinks variant="row" />
    <div className="footer">
      <div className="footer-brand"><img src={channelLogo} alt="" /> جزيرة المرح · نشاهد ونتعلّم معاً</div>
      <span>وقت الحكاية أجمل بصحبة العائلة · <Link href="/privacy" className="footer-link">الخصوصية وركن الأهل</Link></span>
    </div>
    {ADS.client && <p className="footer-note">الإعلانات على الموقع غير مخصّصة ولا تعتمد على اهتمامات الطفل.</p>}
  </footer>;
}
