import { BookOpen, Compass, Gamepad2, Home, LockKeyhole, Sparkles } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import logo from '@assets/logo_1793532475854.png';

const links = [
  { href: '/', label: 'المكتبة', icon: Home },
  { href: '/games', label: 'الألعاب', icon: Gamepad2 },
  { href: '/stories', label: 'القصص', icon: BookOpen },
  { href: '/learn', label: 'نتعلّم', icon: Sparkles },
];

export default function IslandHeader() {
  const [location] = useLocation();
  return <header className="site-shell global-header" dir="rtl">
    <Link href="/" className="brand-lockup" data-testid="brand-fun-island" aria-label="جزيرة المرح، الصفحة الرئيسية">
      <img src={logo} alt="شعار جزيرة المرح" />
      <span><strong className="brand-name">جزيرة المرح</strong><small className="brand-sub">حكايات صغيرة، عوالم كبيرة</small></span>
    </Link>
    <nav className="island-nav" aria-label="التنقل الرئيسي">
      {links.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-link ${location === href ? 'is-active' : ''}`} aria-current={location === href ? 'page' : undefined} data-testid={`link-nav-${href === '/' ? 'home' : href.slice(1)}`}>
        <Icon size={17} aria-hidden="true" /><span>{label}</span>
      </Link>)}
    </nav>
    <div className="safe-note"><span className="safe-dot" /><LockKeyhole size={15} aria-hidden="true" /><span>مساحة آمنة للعائلة</span></div>
  </header>;
}
