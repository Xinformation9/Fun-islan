const clouds = [[8, 100, -20], [22, 150, -70], [38, 190, -130]];
const bubbles = Array.from({ length: 8 }, (_, i) => ({ size: 14 + ((i * 7) % 22), left: 6 + i * 12, dur: 20 + ((i * 5) % 14), delay: -((i * 4) % 18) }));

export default function AmbientScene() {
  return <div className="bg-scene" aria-hidden="true">
    {clouds.map(([top, dur, delay]) => <i key={top} className="cloud" style={{ top: `${top}%`, animationDuration: `${dur}s`, animationDelay: `${delay}s` }} />)}
    {bubbles.map((b, i) => <i key={i} className="bubble" style={{ width: b.size, height: b.size, left: `${b.left}%`, animationDuration: `${b.dur}s`, animationDelay: `${b.delay}s` }} />)}
    <i className="wave" /><i className="wave w2" />
  </div>;
}
