import { useEffect, useRef, useState } from 'react';
import { ADS } from '@/lib/site';

let libLoaded = false;

/** Calm, labeled ad area. Hidden until AdSense IDs are set. Add ?ads=preview to see placement. */
export default function AdSlot({ slot }: { slot: keyof typeof ADS.slots }) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  const id = ADS.slots[slot];
  const live = Boolean(ADS.client && id);
  const preview = /[?&]ads=preview/.test(window.location.search);

  useEffect(() => {
    if (!live || !ref.current) return;
    const io = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setVisible(true); io.disconnect(); }
    }, { rootMargin: '300px' });
    io.observe(ref.current);
    return () => io.disconnect();
  }, [live]);

  useEffect(() => {
    if (!visible) return;
    if (!libLoaded) {
      libLoaded = true;
      const s = document.createElement('script');
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADS.client}`;
      document.head.appendChild(s);
    }
    try {
      const w = window as unknown as { adsbygoogle?: unknown[] };
      (w.adsbygoogle = w.adsbygoogle || []).push({});
    } catch { /* ad blockers may throw; ignore */ }
  }, [visible]);

  if (!live && !preview) return null;
  return <aside ref={ref} className="ad-slot" aria-label="إعلان">
    {live
      ? (visible ? <ins className="adsbygoogle" style={{ display: 'block', minHeight: 100 }} data-ad-client={ADS.client} data-ad-slot={id} data-ad-format="auto" data-full-width-responsive="true" data-tag-for-child-directed-treatment="1" /> : <div style={{ minHeight: 100 }} />)
      : <div className="ad-box">مساحة إعلانية (معاينة)</div>}
  </aside>;
}
