# Usage: python set_domain.py https://your-real-domain.com
import sys, pathlib
new = sys.argv[1].rstrip('/')
for p in [pathlib.Path('index.html'), *pathlib.Path('public').glob('*')]:
    if p.is_file() and p.suffix in {'.html', '.xml', '.txt'}:
        s = p.read_text(encoding='utf8')
        if 'https://YOUR-DOMAIN.com' in s:
            p.write_text(s.replace('https://YOUR-DOMAIN.com', new), encoding='utf8')
print('done')
