# SEO / GEO / AEO / AdSense

1. النطاق: `python set_domain.py https://نطاقك.com` (يستبدل `https://YOUR-DOMAIN.com` في index.html و public).
2. ثم أرسل `sitemap.xml` إلى Google Search Console.
3. AdSense: انسخ `.env.example` إلى `.env` وضع المعرّفات. معاينة الأماكن: أضف `?ads=preview` للرابط. صحّح `public/ads.txt`.
4. فعّل رسالة الموافقة من AdSense > Privacy & messaging، وعيّن الموقع موجّهاً للأطفال.
5. غيّر البريد في `src/lib/site.ts`.
