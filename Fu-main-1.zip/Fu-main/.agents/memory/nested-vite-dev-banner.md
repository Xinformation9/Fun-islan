---
name: Nested Vite dev-banner routing
description: A Vite dev-only banner asset can be served from the proxy root instead of a non-root artifact's base path.
---

When a Vite artifact is mounted under a path such as `/fun-island-web/`, the Replit dev-banner plugin can request its script from the proxy root. The page may still render, but the browser reports a MIME-type or 404 error for the banner script.

**Why:** The proxy routes by artifact path, so root-relative development assets can land outside the artifact that owns them.

**How to apply:** If a nested Vite artifact shows this specific banner-script error, disable the dev-banner plugin for that artifact and verify the page and browser logs again.
